import React, { useState } from 'react';
import { View, Text, Switch, StyleSheet, Alert } from 'react-native';
import PrimaryButton from '../../components/PrimaryButton';
import StepProgressBar from '../../components/StepProgressBar';
import useRegistrationStore from '../../store/registrationStore';
import { fonts } from '../../theme';

const normalizeBoolean = (value) => {
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    return normalized === 'true' || normalized === '1' || normalized === 'yes';
  }
  return !!value;
};

export default function ConsentScreen({ navigation }) {
  const { data, setField } = useRegistrationStore();
  const [consentData, setConsentData] = useState(normalizeBoolean(data.consentData));
  const [consentMarketing, setConsentMarketing] = useState(normalizeBoolean(data.consentMarketing));


  const onNext = () => {
    const requiredConsent = normalizeBoolean(consentData);
    const marketingConsent = normalizeBoolean(consentMarketing);
    setField('consentData', requiredConsent);
    setField('consentMarketing', marketingConsent);
    if (!requiredConsent) return Alert.alert('Please accept the Data Consent to continue.');
    navigation.navigate('ReviewSubmit');
  };

  return (
    <View style={styles.wrap}>
      <StepProgressBar step={6} />
      <Text style={[fonts.h2, { marginBottom: 12 }]}>Consents</Text>
      <View style={styles.row}>
        <Text style={styles.label}>I agree to data processing for eligibility & verification</Text>
        <Switch value={normalizeBoolean(consentData)} onValueChange={setConsentData} />
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>I agree to receive program updates (optional)</Text>
        <Switch value={normalizeBoolean(consentMarketing)} onValueChange={setConsentMarketing} />
      </View>
      <PrimaryButton title="Continue" onPress={onNext} />
    </View>
  );
}
const styles = StyleSheet.create({
  wrap: { flex: 1, padding: 20 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  label: { flex: 1, marginRight: 12 }
});
